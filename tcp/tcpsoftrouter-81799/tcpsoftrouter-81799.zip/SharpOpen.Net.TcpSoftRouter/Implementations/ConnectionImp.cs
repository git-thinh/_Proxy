﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Diagnostics;

namespace SharpOpen.Net.TcpSoftRouter.Implementations
{
    public class ConnectionImp : Connection
    {
        public ConnectionImp()
        {
            
        }
    }
}
