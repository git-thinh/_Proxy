/* ---------------------------------------------------------------------------
 *
 * Copyright (c) Routrek Networks, Inc.    All Rights Reserved..
 * 
 * This file is a part of the Granados SSH Client Library that is subject to
 * the license included in the distributed package.
 * You may not use this file except in compliance with the license.
 * 
 * ---------------------------------------------------------------------------
 */
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Granados")]
[assembly: AssemblyDescription("SSH Client Library")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Routrek Networks, Inc")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]		


[assembly: AssemblyVersion("2.0.0")]

[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("..\\..\\granados.snk")]
[assembly: AssemblyKeyName("")]
/*
[assembly: AssemblyDelaySign(true)]
[assembly: AssemblyKeyFile("..\\..\\granados.pub")]
[assembly: AssemblyKeyName("")]
*/