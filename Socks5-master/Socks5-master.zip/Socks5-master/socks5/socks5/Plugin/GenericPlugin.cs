﻿using System;
using System.Collections.Generic;
using System.Text;

namespace socks5.Plugin
{
    public interface GenericPlugin
    {
        bool Enabled { get; set; }
    }
}
