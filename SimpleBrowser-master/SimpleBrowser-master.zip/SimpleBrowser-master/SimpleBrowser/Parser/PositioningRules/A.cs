﻿namespace SimpleBrowser.Parser.PositioningRules
{
	class A : BodyElementPositioningRule
	{
		// static readonly string[] _allowedParentTags = new [] { "" };
		public override string TagName { get { return "a"; } }
	}
}
