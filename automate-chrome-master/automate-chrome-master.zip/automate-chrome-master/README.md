automate-chrome
===============

Example of Chrome automation

The Chrome automation using Chrome Remote Debugging.
See http://markcz.wordpress.com/2012/02/18/automating-chrome-browser-from-csharp/ For more details.
